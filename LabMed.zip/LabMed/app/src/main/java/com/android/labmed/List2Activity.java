package com.android.labmed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.android.labmed.Adapter.Item;
import com.android.labmed.Adapter.MyAdapter;
import com.android.labmed.Adapter.MyAdapter2;
import com.android.labmed.databinding.ActivityList2Binding;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class List2Activity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    ActivityList2Binding activityList2Binding;
    static final float END_SCALE = 0.7f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityList2Binding=ActivityList2Binding.inflate(getLayoutInflater());
        View  view=activityList2Binding.getRoot();
        setContentView(view);
        Intent intent = getIntent();
        String name =intent.getStringExtra("otherPageTitle");
        activityList2Binding.titleTv.setText(name);
        listDataShow();
        naviagtionDrawer();
    }

    private void listDataShow() {
        Intent intent = getIntent();
        String key=intent.getStringExtra("otherPageTitle");
        List<Item> items = new ArrayList<Item>();
        if (key.equals("CSF Test")){

            items.add(new Item("Determination of Glucose",R.drawable.blood1));
            items.add(new Item("Determination of Protein",R.drawable.blood1));
            items.add(new Item("Determination of Globulin",R.drawable.blood1));
        } else if (key.equals("Blood Cells Count Test")) {
            items.add(new Item("RBC Count Test",R.drawable.blood));
            items.add(new Item("WBC Count Test",R.drawable.blood));
        } else if (key.equals("ELISA TEST")) {
            items.add(new Item("Introduction",R.drawable.laboratory));
        }
        activityList2Binding.rvContacts.setLayoutManager(new LinearLayoutManager(this));
        activityList2Binding.rvContacts.setAdapter(new MyAdapter2(getApplicationContext(),items));

        activityList2Binding.rvContacts.setLayoutManager(new LinearLayoutManager(this)); // set LayoutManager to RecyclerView

        activityList2Binding.rvContacts.setAdapter(new MyAdapter2(getApplicationContext(),items));
    }

    public void onBackPressed() {
        if (activityList2Binding.getRoot().isDrawerVisible(GravityCompat.START)) {
            activityList2Binding.getRoot().closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }
    private void naviagtionDrawer(){
        //Naviagtion Drawer
        activityList2Binding.navView.bringToFront();
        activityList2Binding.navView.setNavigationItemSelectedListener( this);
        activityList2Binding.menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(activityList2Binding.getRoot().isDrawerVisible(GravityCompat.START))
                    activityList2Binding.getRoot().closeDrawer(GravityCompat.START);
                else activityList2Binding.getRoot().openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        activityList2Binding.drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                activityList2Binding.content.setScaleX(offsetScale);
                activityList2Binding.content.setScaleY(offsetScale);
                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = activityList2Binding.content.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                activityList2Binding.content.setTranslationX(xTranslation);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }
}
