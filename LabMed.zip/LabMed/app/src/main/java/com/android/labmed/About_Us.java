package com.android.labmed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.airbnb.lottie.BuildConfig;
import com.android.labmed.databinding.ActivityAboutUsBinding;
import com.google.android.material.navigation.NavigationView;

public class About_Us extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    ActivityAboutUsBinding activityAboutUsBinding;
    static final float END_SCALE = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityAboutUsBinding = ActivityAboutUsBinding.inflate(getLayoutInflater());
        View view = activityAboutUsBinding.getRoot();
        setContentView(view);

        naviagtionDrawer();
    }

    public void onBackPressed() {
        if (activityAboutUsBinding.getRoot().isDrawerVisible(GravityCompat.START)) {
            activityAboutUsBinding.getRoot().closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }

    private void naviagtionDrawer() {
        //Naviagtion Drawer
        activityAboutUsBinding.navView.bringToFront();
        activityAboutUsBinding.navView.setNavigationItemSelectedListener(this);
        activityAboutUsBinding.menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (activityAboutUsBinding.getRoot().isDrawerVisible(GravityCompat.START))
                    activityAboutUsBinding.getRoot().closeDrawer(GravityCompat.START);
                else activityAboutUsBinding.getRoot().openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        activityAboutUsBinding.drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                activityAboutUsBinding.content.setScaleX(offsetScale);
                activityAboutUsBinding.content.setScaleY(offsetScale);
                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = activityAboutUsBinding.content.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                activityAboutUsBinding.content.setTranslationX(xTranslation);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        if (id == R.id.nav_about) {
            Intent intent = new Intent(this, About_Us.class);
            startActivity(intent);
            finish();
        } else if (id==R.id.nav_share) {

            ShareCompat.IntentBuilder.from(this)
                    .setType("text/plain")
                    .setChooserTitle("Share App")
                    .setText("https://play.google.com/store/apps/developer?id=Heet+Vadecha")
                    .startChooser();


        } else if (id==R.id.nav_other) {
            final String appPackageName = getPackageName();
            Intent sendIntent = new Intent();
            sendIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Check out the App at: https://play.google.com/store/apps/details?id=" + appPackageName);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        }
        activityAboutUsBinding.drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
