package com.android.labmed.Adapter;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.labmed.List2Activity;
import com.android.labmed.MainActivity;
import com.android.labmed.R;

import java.util.List;

public class MyAdapter2 extends RecyclerView.Adapter<MyViewHolder>  {


    Context context;
    List<Item> items;

    public MyAdapter2(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_listview,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull  MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.nameView.setText(items.get(position).getName());
        holder.imageView.setImageResource(items.get(position).getImage());
        if (items.get(position).getName().equals("RBC Count Test")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "Blood Cells Count Test"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        } else if (items.get(position).getName().equals("WBC Count Test")) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "Blood Cells Count Test"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }else if (items.get(position).getName().equals("INDIRECT ELISA")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "ELISA TEST"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }else if (items.get(position).getName().equals("SANDWICH ELISA")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "ELISA TEST"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }else if (items.get(position).getName().equals("Introduction")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "ELISA TEST"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }else if (items.get(position).getName().equals("Determination of Glucose")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "CSF Test"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        } else if (items.get(position).getName().equals("Determination of Protein")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "CSF Test"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }else if (items.get(position).getName().equals("Determination of Globulin")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, MainActivity.class);
                    intent.putExtra("name", "CSF Test"+"/"+items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
