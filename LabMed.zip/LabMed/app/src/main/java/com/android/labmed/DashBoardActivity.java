package com.android.labmed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ShareCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.labmed.databinding.ActivityDashBoardBinding;
import com.google.android.material.navigation.NavigationView;

public class DashBoardActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    ActivityDashBoardBinding activityDashBoardBinding;
    static final float END_SCALE = 0.7f;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityDashBoardBinding=ActivityDashBoardBinding.inflate(getLayoutInflater());
        View view = activityDashBoardBinding.getRoot();
        sharedPreferences = getSharedPreferences("application", Context.MODE_PRIVATE);

        editor= sharedPreferences.edit();
        setContentView(view);
        viewClickLisener();
        naviagtionDrawer();

    }

    private void viewClickLisener() {
        activityDashBoardBinding.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashBoardActivity.this,ListActivity.class);
                intent.putExtra("title","Normal Value");
                intent.putExtra("key","nv");
                editor.putString("title","Normal Value");
                editor.apply();
                startActivity(intent);
            }
        });
        activityDashBoardBinding.cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashBoardActivity.this,ListActivity.class);
                intent.putExtra("title","Hematological Test");
                intent.putExtra("key","hm");
                editor.putString("title","Hematological Test");
                editor.apply();
                startActivity(intent);
            }
        });
        activityDashBoardBinding.cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashBoardActivity.this,ListActivity.class);
                intent.putExtra("title","Biochemistry Test");
                intent.putExtra("key","bi");
                editor.putString("title","Biochemistry Test");
                editor.apply();
                startActivity(intent);
            }
        });
        activityDashBoardBinding.cardView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashBoardActivity.this,ListActivity.class);
                intent.putExtra("title","Microbiology Test");
                intent.putExtra("key","mi");
                editor.putString("title","Microbiology Test");
                editor.apply();
                startActivity(intent);
            }
        });
        activityDashBoardBinding.cardView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DashBoardActivity.this,ListActivity.class);
                intent.putExtra("title","Clinical Path Test");
                intent.putExtra("key","cl");
                editor.putString("title","Clinical Path Test");
                editor.apply();
                startActivity(intent);
            }
        });
    }

    public void onBackPressed() {
        if (activityDashBoardBinding.getRoot().isDrawerVisible(GravityCompat.START)) {
            activityDashBoardBinding.getRoot().closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }
    private void naviagtionDrawer(){
        //Naviagtion Drawer
        activityDashBoardBinding.navView.bringToFront();
        activityDashBoardBinding.navView.setNavigationItemSelectedListener( this);
        activityDashBoardBinding.menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(activityDashBoardBinding.getRoot().isDrawerVisible(GravityCompat.START))
                    activityDashBoardBinding.getRoot().closeDrawer(GravityCompat.START);
                else activityDashBoardBinding.getRoot().openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        activityDashBoardBinding.drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                activityDashBoardBinding.content.setScaleX(offsetScale);
                activityDashBoardBinding.content.setScaleY(offsetScale);
                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = activityDashBoardBinding.content.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                activityDashBoardBinding.content.setTranslationX(xTranslation);
            }
        });
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
       int id =menuItem.getItemId();
        if (id == R.id.nav_about) {
            Intent intent = new Intent(this, About_Us.class);
            startActivity(intent);
            finish();
        } else if (id==R.id.nav_share) {


            final String appPackageName = getPackageName();
            Intent sendIntent = new Intent();
            sendIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Check out the App at: https://play.google.com/store/apps/details?id=" + appPackageName);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        } else if (id==R.id.nav_other) {

            ShareCompat.IntentBuilder.from(this)
                    .setType("text/plain")
                    .setChooserTitle("Share App")
                    .setText("https://play.google.com/store/apps/developer?id=Heet+Vadecha")
                    .startChooser();

        }
        activityDashBoardBinding.drawerLayout.closeDrawer(GravityCompat.START);
       return true;
    }
}
