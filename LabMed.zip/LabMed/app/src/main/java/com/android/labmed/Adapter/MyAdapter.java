package com.android.labmed.Adapter;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK;
import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static android.content.Intent.getIntent;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.labmed.List2Activity;
import com.android.labmed.ListActivity;
import com.android.labmed.MainActivity;
import com.android.labmed.R;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {


    Context context;
    List<Item> items;

    public MyAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_listview,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull  MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.nameView.setText(items.get(position).getName());
        holder.imageView.setImageResource(items.get(position).getImage());
       if (items.get(position).getName().equals("Blood Cells Count Test")){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, List2Activity.class);
                    intent.putExtra("otherPageTitle",items.get(position).getName());
                    intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
       } else if (items.get(position).getName().equals("CSF Test")) {
           holder.itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent intent=new Intent(context, List2Activity.class);
                   intent.putExtra("otherPageTitle",items.get(position).getName());
                   intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                   context.startActivity(intent);
               }
           });
       }else if (items.get(position).getName().equals("ELISA TEST")){
           holder.itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent intent=new Intent(context, List2Activity.class);
                   intent.putExtra("otherPageTitle",items.get(position).getName());
                   intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                   context.startActivity(intent);
               }
           });
       }else {
           holder.itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {

                   Intent intent = new Intent(context, MainActivity.class);
                   intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                   intent.putExtra("name", items.get(position).getName());

                   context.startActivity(intent);
               }
           });
       }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
