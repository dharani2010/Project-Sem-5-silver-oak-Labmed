package com.android.labmed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.android.labmed.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private ActivityMainBinding activityMainBinding;
    SharedPreferences sharedPreferences;
    static final float END_SCALE = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = activityMainBinding.getRoot();
        setContentView(view);
        sharedPreferences = getSharedPreferences("application", Context.MODE_PRIVATE);
        naviagtionDrawer();
        Intent intent=getIntent();
        String title=sharedPreferences.getString("title","").replace(" ","-").toLowerCase();
        String name =intent.getStringExtra("name").replace(" ","-").toLowerCase();

        activityMainBinding.helpWebview.getSettings().setJavaScriptEnabled(true);
        String url="https://sites.google.com/view/hematologicaltest/"+title+"/"+name;
        Log.d("url",""+url);
        activityMainBinding.helpWebview.loadUrl(url);

    }

    public void onBackPressed() {
        if (activityMainBinding.getRoot().isDrawerVisible(GravityCompat.START)) {
            activityMainBinding.getRoot().closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }
    private void naviagtionDrawer(){
        //Naviagtion Drawer
        activityMainBinding.navView.bringToFront();
        activityMainBinding.navView.setNavigationItemSelectedListener( this);
        activityMainBinding.menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(activityMainBinding.getRoot().isDrawerVisible(GravityCompat.START))
                    activityMainBinding.getRoot().closeDrawer(GravityCompat.START);
                else activityMainBinding.getRoot().openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        activityMainBinding.drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                activityMainBinding.content.setScaleX(offsetScale);
                activityMainBinding.content.setScaleY(offsetScale);
                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = activityMainBinding.content.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                activityMainBinding.content.setTranslationX(xTranslation);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }

}
