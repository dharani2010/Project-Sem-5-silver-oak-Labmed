package com.android.labmed;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.android.labmed.Adapter.Item;
import com.android.labmed.Adapter.MyAdapter;
import com.android.labmed.Adapter.MyListData;
import com.android.labmed.databinding.ActivityListBinding;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    ActivityListBinding activityListBinding;
    static final float END_SCALE = 0.7f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityListBinding=ActivityListBinding.inflate(getLayoutInflater());
        View view=activityListBinding.getRoot();
        setContentView(view);
        Intent intent = getIntent();
        String name =intent.getStringExtra("title");
        activityListBinding.titleTv.setText(name);
        listDataShow();
        naviagtionDrawer();
    }

    private void listDataShow() {
        Intent intent = getIntent();
        String key=intent.getStringExtra("key");
        List<Item> items = new ArrayList<Item>();
        if (key.equals("nv")){
            items.add(new Item("Hematology",R.mipmap.ic_launcher));
            items.add(new Item("Biochemistry",R.mipmap.ic_launcher));
        } else if (key.equals("hm")) {
            items.add(new Item("Collection of Blood",R.drawable.blood));
            items.add(new Item("Blood Cells Count Test",R.drawable.blood));
            items.add(new Item("ESR Test",R.drawable.blood));
            items.add(new Item("PCV Test",R.drawable.blood));
            items.add(new Item("Hemoglobin Test",R.drawable.blood));
            items.add(new Item("DLC Count Test",R.drawable.blood));
            items.add(new Item("Blood Group Test",R.drawable.blood));
            items.add(new Item("G-6-PD Test",R.drawable.blood));
            items.add(new Item("Bleeding Time Test",R.drawable.blood));
            items.add(new Item("Clotting Time Test",R.drawable.blood));
            items.add(new Item("Prothrombin Time Test",R.drawable.blood));
            items.add(new Item("aPPT Test",R.drawable.blood));
            items.add(new Item("Osmotic Fragility Test",R.drawable.blood));
            items.add(new Item("Platelets Function Test",R.drawable.blood));
            items.add(new Item("Clot Reaction Test",R.drawable.blood));
            items.add(new Item("Fibrinolysis Test",R.drawable.blood));
            items.add(new Item("Red Cell PK Test",R.drawable.blood));
        } else if (key.equals("bi")) {
            items.add(new Item("Blood Glucose Test",R.drawable.flask));
            items.add(new Item("Blood Urea Test",R.drawable.flask));
            items.add(new Item("Creatinine Clearance Test",R.drawable.flask));
            items.add(new Item("Serum CPK Test",R.drawable.flask));
            items.add(new Item("Total Bilirubin Test",R.drawable.flask));
            items.add(new Item("Serum Cholesterol Test",R.drawable.flask));
            items.add(new Item("Serum Chloride Test",R.drawable.flask));
            items.add(new Item("Serum Calcium Test",R.drawable.flask));
            items.add(new Item("Serum Amylase Test",R.drawable.flask));
            items.add(new Item("Serum Phosphate Test",R.drawable.flask));
            items.add(new Item("Serum Creatinine Test",R.drawable.flask));
            items.add(new Item("Serum Uric Acid Test",R.drawable.flask));
            items.add(new Item("SGPT Test",R.drawable.flask));
            items.add(new Item("Serum Acid Phosphatase Test",R.drawable.flask));
            items.add(new Item("Serum Alkaline Phosphatase Test",R.drawable.flask));
            items.add(new Item("Lipid Profile",R.drawable.flask));

        } else if (key.equals("mi")) {
            items.add(new Item("VDRL Test",R.drawable.laboratory));
            items.add(new Item("WIDAL Test",R.drawable.laboratory));
            items.add(new Item("ELISA TEST",R.drawable.laboratory));
            items.add(new Item("BILE SOLUBILITY TEST",R.drawable.laboratory));
            items.add(new Item("SPUTUM TEST",R.drawable.laboratory));
            items.add(new Item("MALARIA PARASITE TEST",R.drawable.laboratory));
            items.add(new Item("CATALASE TEST",R.drawable.laboratory));
            items.add(new Item("Coagulase Test",R.drawable.laboratory));
            items.add(new Item("IMVIC Test",R.drawable.laboratory));
            items.add(new Item("Nitrate Reduction Test",R.drawable.laboratory));
            items.add(new Item("Hemagglutination Test",R.drawable.laboratory));
            items.add(new Item("C-Reactive Protein Test",R.drawable.laboratory));
            items.add(new Item("Malaria Antigen Test",R.drawable.laboratory));
            items.add(new Item("Skin Smear for AFB",R.drawable.laboratory));
            items.add(new Item("FTA-ABS Test",R.drawable.laboratory));
            items.add(new Item("TPHA Test",R.drawable.laboratory));
            items.add(new Item("Brucella Agglutination Test",R.drawable.laboratory));
            items.add(new Item("Whooping Cough Test",R.drawable.laboratory));
            items.add(new Item("Bacterial Examination of Milk",R.drawable.laboratory));
            items.add(new Item("Water Analysis for Bacteria",R.drawable.laboratory));
            items.add(new Item("Bacterial Examination of Food",R.drawable.laboratory));
            items.add(new Item("HIV Antigen Test",R.drawable.laboratory));
            items.add(new Item("HCV Test",R.drawable.laboratory));
            items.add(new Item("Dengue Card Test",R.drawable.laboratory));
            items.add(new Item("Chikungunya Card Test",R.drawable.laboratory));
            items.add(new Item("Hepatitis B Antigen Test",R.drawable.laboratory));
            items.add(new Item("Thyroid Card Test",R.drawable.laboratory));
            items.add(new Item("Neutralization Test",R.drawable.laboratory));
            items.add(new Item("Triple Sugar Iron Agar Test",R.drawable.laboratory));
            items.add(new Item("Phenylalanine Deaminase Test",R.drawable.laboratory));
            items.add(new Item("Gelatin Liquefaction Test",R.drawable.laboratory));
            items.add(new Item("Urease Test",R.drawable.laboratory));
            items.add(new Item("Oxidation Fermentation Test",R.drawable.laboratory));

        }else if (key.equals("cl")){
            items.add(new Item("Bile Salt Test",R.drawable.blood1));
            items.add(new Item("Bile Pigment Test",R.drawable.blood1));
            items.add(new Item("Kitone Bodies Test",R.drawable.blood1));
            items.add(new Item("Occult Blood Test",R.drawable.blood1));
            items.add(new Item("Porphobilinogen Test",R.drawable.blood1));
            items.add(new Item("Semen Analysis Test",R.drawable.blood1));
            items.add(new Item("Urine Glucose Test",R.drawable.blood1));
            items.add(new Item("Urine Protein Test",R.drawable.blood1));
            items.add(new Item("CSF Test",R.drawable.blood1));
            items.add(new Item("Urine Uric Acid Test",R.drawable.blood1));
            items.add(new Item("Urobilinogen Test",R.drawable.blood1));
            items.add(new Item("Urine for Sugar Protein",R.drawable.blood1));
            items.add(new Item("Urine for Pregnancy Test",R.drawable.blood1));
        }
        activityListBinding.rvContacts.setLayoutManager(new LinearLayoutManager(this));
        activityListBinding.rvContacts.setAdapter(new MyAdapter(getApplicationContext(),items));

        activityListBinding.rvContacts.setLayoutManager(new LinearLayoutManager(this)); // set LayoutManager to RecyclerView

        activityListBinding.rvContacts.setAdapter(new MyAdapter(getApplicationContext(),items));
    }

    public void onBackPressed() {
        if (activityListBinding.getRoot().isDrawerVisible(GravityCompat.START)) {
            activityListBinding.getRoot().closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }
    private void naviagtionDrawer(){
        //Naviagtion Drawer
        activityListBinding.navView.bringToFront();
        activityListBinding.navView.setNavigationItemSelectedListener( this);
        activityListBinding.menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(activityListBinding.getRoot().isDrawerVisible(GravityCompat.START))
                    activityListBinding.getRoot().closeDrawer(GravityCompat.START);
                else activityListBinding.getRoot().openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        activityListBinding.drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                activityListBinding.content.setScaleX(offsetScale);
                activityListBinding.content.setScaleY(offsetScale);
                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = activityListBinding.content.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                activityListBinding.content.setTranslationX(xTranslation);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }
}
