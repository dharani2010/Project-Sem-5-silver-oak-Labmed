package com.android.labmed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.labmed.databinding.ActivitySplashScreenBinding;

import java.text.Annotation;

public class ActivitySplashScreen extends AppCompatActivity {
    private ActivitySplashScreenBinding activitySplashScreenBinding;
    SharedPreferences sharedPreferences;
    private static int SPLASH_SCREEN=5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activitySplashScreenBinding=activitySplashScreenBinding.inflate(getLayoutInflater());
        View view=activitySplashScreenBinding.getRoot();
        setContentView(view);


        // Check if we need to display our OnboardingSupportFragment

            new Handler().postDelayed(new Runnable() {
                                          @Override
                                          public void run() {
                                              Intent intent = new Intent(ActivitySplashScreen.this, DashBoardActivity.class);
                                              startActivity(intent);
                                              finish();
                                          }
                                      }, //Pass time here
                    SPLASH_SCREEN);

    }
}
